import React, { useState, useRef, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI } from '@google/genai';
import QRCode from 'qrcode';

interface AnalysisRecord {
    id: number;
    imagePreview: string;
    analysis: string;
    timestamp: string;
    location: string;
}

// beforeinstallprompt 이벤트의 타입을 정의합니다.
interface BeforeInstallPromptEvent extends Event {
    readonly platforms: Array<string>;
    readonly userChoice: Promise<{
        outcome: 'accepted' | 'dismissed',
        platform: string
    }>;
    prompt(): Promise<void>;
}

declare global {
  interface Window {
    GEMINI_API_KEY: string;
  }
}


const InstallModal = ({ onClose }: { onClose: () => void }) => {
    const [qrCodeUrl, setQrCodeUrl] = useState('');

    useEffect(() => {
        QRCode.toDataURL(window.location.href, { width: 256, margin: 2, errorCorrectionLevel: 'H' })
            .then(url => {
                setQrCodeUrl(url);
            })
            .catch(err => {
                console.error("Failed to generate QR code", err);
            });
    }, []);

    return (
        <div className="install-overlay" onClick={onClose}>
            <div className="install-modal" onClick={e => e.stopPropagation()}>
                <h2>홈 화면에 앱 추가하기</h2>

                <div className="install-section">
                    <h3>현재 기기에 설치</h3>
                    <p>브라우저 메뉴를 사용하여 홈 화면에 바로가기를 추가하세요.</p>
                    <div className="instruction-wrapper">
                        <div className="instruction-item">
                            <h4><span className="material-symbols-outlined">smartphone</span> iPhone (Safari)</h4>
                            <ol>
                                <li>화면 하단의 <span className="material-symbols-outlined inline-icon">ios_share</span> 공유 버튼을 누르세요.</li>
                                <li>메뉴를 아래로 내려 <span className="material-symbols-outlined inline-icon">add_box</span> '홈 화면에 추가'를 선택하세요.</li>
                            </ol>
                        </div>
                         <div className="instruction-item">
                            <h4><span className="material-symbols-outlined">android</span> 기타 브라우저</h4>
                            <ol>
                                <li><span className="material-symbols-outlined inline-icon">more_vert</span> 메뉴 버튼을 누르세요.</li>
                                <li>'홈 화면에 추가' 또는 '앱 설치'를 선택하세요.</li>
                            </ol>
                        </div>
                    </div>
                </div>

                <div className="divider"></div>

                <div className="install-section">
                    <h3>다른 기기와 공유</h3>
                    <p>
                        다른 기기의 카메라로 QR 코드를 스캔한 후,
                        <strong> 반드시 웹 브라우저(Safari/Chrome)에서 링크를 여세요.</strong>
                    </p>
                    {qrCodeUrl ? (
                        <img src={qrCodeUrl} alt="웹사이트 QR 코드" className="qr-code" />
                    ) : (
                        <div className="loader-container"><div className="loader"></div></div>
                    )}
                </div>

                <button onClick={onClose} className="button secondary">닫기</button>
            </div>
        </div>
    );
};


const App = () => {
    const [image, setImage] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [history, setHistory] = useState<AnalysisRecord[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
    const [isInstallModalOpen, setIsInstallModalOpen] = useState<boolean>(false);
    const [installPromptEvent, setInstallPromptEvent] = useState<BeforeInstallPromptEvent | null>(null);


    const galleryInputRef = useRef<HTMLInputElement>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    
    useEffect(() => {
        if ('serviceWorker' in navigator) {
          window.addEventListener('load', () => {
            navigator.serviceWorker.register('sw.js').then(registration => {
              console.log('SW registered: ', registration);
            }).catch(registrationError => {
              console.log('SW registration failed: ', registrationError);
            });
          });
        }
      }, []);

    useEffect(() => {
        const handleBeforeInstallPrompt = (event: Event) => {
            event.preventDefault();
            setInstallPromptEvent(event as BeforeInstallPromptEvent);
            console.log("`beforeinstallprompt` event was fired.");
        };

        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

        return () => {
            window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        };
    }, []);

    useEffect(() => {
        try {
            const storedHistory = localStorage.getItem('analysisHistory');
            if (storedHistory) {
                setHistory(JSON.parse(storedHistory));
            }
        } catch (error) {
            console.error("Failed to load history from localStorage", error);
        }
    }, []);

    useEffect(() => {
        if (history.length > 0) {
            try {
                localStorage.setItem('analysisHistory', JSON.stringify(history));
            } catch (error) {
                console.error("Failed to save history to localStorage", error);
            }
        }
    }, [history]);

    const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setImage(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
                setError('');
            };
            reader.readAsDataURL(file);
        }
        event.target.value = '';
    };

    const fileToGenerativePart = async (file: File) => {
        const base64EncodedDataPromise = new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(file);
        });
        return {
            inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
        };
    };
    
    const getCurrentLocation = (): Promise<string> => {
        return new Promise((resolve) => {
            if (!navigator.geolocation) {
                resolve("위치 정보를 사용할 수 없습니다.");
                return;
            }
            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    const { latitude, longitude } = position.coords;
                    const fallbackLocation = `위도: ${latitude.toFixed(4)}, 경도: ${longitude.toFixed(4)}`;

                    try {
                        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}&accept-language=ko`);
                        if (!response.ok) {
                            resolve(fallbackLocation);
                            return;
                        }
                        const data = await response.json();
                        resolve(data.display_name || fallbackLocation);
                    } catch (err) {
                        console.error("Reverse geocoding error:", err);
                        resolve(fallbackLocation);
                    }
                },
                () => {
                    resolve("위치 정보 접근이 거부되었습니다.");
                },
                { timeout: 10000 }
            );
        });
    };

    const clearInputs = () => {
        setImage(null);
        setImagePreview(null);
        setError('');
    };

    const analyzeImage = async () => {
        if (!image || !imagePreview) {
            setError('먼저 사진을 선택해주세요.');
            return;
        }

        if (!window.GEMINI_API_KEY) {
            setError('API 키가 설정되지 않았습니다. GitHub Actions Secret 설정을 확인해주세요.');
            return;
        }

        setIsLoading(true);
        setError('');

        try {
            const ai = new GoogleGenAI({ apiKey: window.GEMINI_API_KEY });
            const imagePart = await fileToGenerativePart(image);
            const textPart = {
                text: "이 사진에 무엇이 보이나요? 사진 속 주요 사물에 대해 한국어로 설명해주세요."
            };

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: { parts: [imagePart, textPart] },
            });
            
            const analysisText = response.text;
            const location = await getCurrentLocation();
            const timestamp = new Date().toLocaleString('ko-KR');

            const newRecord: AnalysisRecord = {
                id: Date.now(),
                imagePreview: imagePreview,
                analysis: analysisText,
                timestamp: timestamp,
                location: location,
            };

            setHistory(prevHistory => [newRecord, ...prevHistory]);
            clearInputs();

        } catch (err) {
            console.error(err);
            setError('사진 분석 중 오류가 발생했습니다. 다시 시도해주세요.');
        } finally {
            setIsLoading(false);
        }
    };

    const openCamera = () => setIsCameraOpen(true);

    const closeCamera = () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            videoRef.current.srcObject = null;
        }
        setIsCameraOpen(false);
    };

    const handleCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(blob => {
                    if (blob) {
                        const file = new File([blob], "capture.jpg", { type: "image/jpeg" });
                        setImage(file);
                        const reader = new FileReader();
                        reader.onloadend = () => {
                            setImagePreview(reader.result as string);
                            setError('');
                        };
                        reader.readAsDataURL(file);
                        closeCamera();
                    }
                }, 'image/jpeg');
            }
        }
    };
    
    const handleInstallClick = async () => {
        if (installPromptEvent) {
            await installPromptEvent.prompt();
            // The user choice is captured by `userChoice` property.
            const { outcome } = await installPromptEvent.userChoice;
            console.log(`User response to the install prompt: ${outcome}`);
            // We can only use the prompt once, so clear it.
            setInstallPromptEvent(null);
        } else {
            // Fallback for browsers that don't support `beforeinstallprompt` (like Safari)
            setIsInstallModalOpen(true);
        }
    };

    useEffect(() => {
        const startCamera = async () => {
            if (isCameraOpen && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ 
                        video: { facingMode: 'environment' } 
                    });
                    if (videoRef.current) {
                        videoRef.current.srcObject = stream;
                    }
                } catch (err) {
                    console.error("카메라 접근 오류:", err);
                    setError("카메라를 사용할 수 없습니다. 권한을 확인해주세요.");
                    closeCamera();
                }
            }
        };
        startCamera();

        return () => {
            if (videoRef.current && videoRef.current.srcObject) {
                const stream = videoRef.current.srcObject as MediaStream;
                stream.getTracks().forEach(track => track.stop());
            }
        };
    }, [isCameraOpen]);
    
    const CameraView = () => (
        <div className="camera-overlay">
            <video ref={videoRef} autoPlay playsInline className="camera-video"></video>
            <canvas ref={canvasRef} className="hidden-input"></canvas>
            <div className="camera-controls">
                <button onClick={closeCamera} className="button secondary">취소</button>
                <button onClick={handleCapture} className="button capture-button">
                     <span className="material-symbols-outlined" aria-hidden="true">photo_camera</span>
                     촬영하기
                </button>
            </div>
        </div>
    );

    return (
        <div className="container">
            {isCameraOpen && <CameraView />}
            {isInstallModalOpen && <InstallModal onClose={() => setIsInstallModalOpen(false)} />}
            
            <h1 className="main-title">
                <span className="material-symbols-outlined" aria-hidden="true">visibility</span>
                <span>AI 사진 분석기</span>
                <button onClick={handleInstallClick} className="install-button" aria-label="앱 설치 안내">
                    <span className="material-symbols-outlined">download</span>
                </button>
            </h1>
            <p>카메라나 갤러리에서 사진을 선택하여 무엇인지 알아보세요.</p>
            
            <div className="input-section">
                <button className="button" onClick={openCamera}>
                    <span className="material-symbols-outlined" aria-hidden="true">photo_camera</span>
                    카메라
                </button>
                <button className="button secondary" onClick={() => galleryInputRef.current?.click()}>
                    <span className="material-symbols-outlined" aria-hidden="true">photo_library</span>
                    갤러리
                </button>
                    <input
                    type="file"
                    accept="image/*"
                    ref={galleryInputRef}
                    onChange={handleImageSelect}
                    className="hidden-input"
                    aria-hidden="true"
                />
            </div>
            
            <div className="image-preview-container">
                {imagePreview ? (
                    <img src={imagePreview} alt="선택된 이미지 미리보기" className="image-preview" />
                ) : (
                    <span className="placeholder-text">사진을 선택해주세요</span>
                )}
            </div>

            <button onClick={analyzeImage} disabled={!image || isLoading} className="button">
                <span className="material-symbols-outlined" aria-hidden="true">psychology</span>
                {isLoading ? '분석 중...' : '사진 분석하기'}
            </button>
            
            {isLoading && <div className="loader" aria-label="로딩 중"></div>}

            {error && <p className="error-message">{error}</p>}

            <div className="history-section">
                <h2>분석 기록</h2>
                {history.length > 0 ? (
                    <div className="history-list">
                        {history.map(record => (
                            <div key={record.id} className="history-item">
                                <img src={record.imagePreview} alt="분석된 이미지" className="history-item-image" />
                                <div className="history-item-content">
                                    <p className="history-item-analysis">{record.analysis}</p>
                                    <div className="history-item-meta">
                                        <span>
                                            <span className="material-symbols-outlined" aria-hidden="true">calendar_month</span>
                                            {record.timestamp}
                                        </span>
                                        <span>
                                            <span className="material-symbols-outlined" aria-hidden="true">location_on</span>
                                            {record.location}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="placeholder-text">아직 분석 기록이 없습니다.</p>
                )}
            </div>
        </div>
    );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);