// A simple, no-op service worker that takes immediate control.

const CACHE_NAME = 'ai-photo-analyzer-v1';
// Add the core files you want to cache here.
const urlsToCache = [
  './',
  './index.html',
  './index.css',
  './manifest.json'
];

self.addEventListener('install', event => {
  // Perform install steps
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        // It's important to note that relative paths like '/index.tsx' won't work for caching
        // as they are processed by the dev server. Only static assets can be reliably cached.
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }
        // Not in cache - fetch from network
        return fetch(event.request);
      }
    )
  );
});